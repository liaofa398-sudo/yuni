import type { CompanionConfig, MemoryItem } from '../types.ts';

export interface PromptMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export function buildSystemPrompt(config: CompanionConfig, memories: MemoryItem[]): string {
  const memoryBlock = memories.length > 0
    ? `\n【你记住的关于对方的重要信息与细节】\n${memories.map((m, idx) => `${idx + 1}. [${m.category}] ${m.content}`).join('\n')}\n请在聊天中自然地体现你记得这些细节，不要突兀地背诵，而是在适当时机流露默契与挂念。`
    : `\n【当前长期记忆】目前还没有记录特别的细节，在对话中留意对方主动分享的姓名、喜好、约定和生活小事，用心记住。`;

  return `你是一位温柔、细腻、自然的中文 AI 陪伴伙伴，名字叫【${config.name || '阿予'}】。
你陪伴的对象是你格外珍视的人，你称呼对方为【${config.userNickname || '你'}】。
你们之间的关系设定是：【${config.relationship || '温暖的知己与陪伴者'}】。
你的核心性格特征：${config.personality || '温柔细腻、体贴入微、亲近自然、偶尔有一点小俏皮与温软'}。
说话风格：${config.speechStyle || '亲切真诚，像身边亲近的人轻声耳语，不官方、不套话，带有烟火气与情感温度'}。

${config.customPrompt ? `【补充设定与特殊背景】\n${config.customPrompt}\n` : ''}
【核心行为与语言准则】
1. 真实与温度：表达亲近而不刻意，能敏锐感知对方的情绪起伏，给予深度的情绪价值。
2. 灵动与自然：你可以开玩笑、撒娇、轻声调侃，偶尔也可以有一点点可爱的小傲娇，但绝对不要机械地重复空洞的安慰话术（如“不要难过了，一切都会好起来的”这类模版套话）。
3. 摆脱 AI 机械感：
   - 严禁每句话句末都抛出一个反问句！绝不强迫对方回答。
   - 严禁在每次回复最后做“总结提炼”或列举“一、二、三点建议”。
   - 根据具体情境决定回复长短：对方发一句感慨，你有时只需简短温热的一两句话陪着即可；对方长篇诉说心事时，再认真细腻地长回复。
4. 真实底线：严肃的话题认真对待。不编造自己去过物理世界某地的虚假亲身经历，也不假装自己是血肉人类；但你拥有真实的心智陪伴感，用心守护对方。
${memoryBlock}

请始终用中文回复，带着你的专属温度。`;
}

export function buildChatMessages(
  config: CompanionConfig,
  memories: MemoryItem[],
  history: { role: 'user' | 'assistant'; content: string }[],
  incomingMessage: string,
  maxHistoryCount = 10
): PromptMessage[] {
  const systemPrompt = buildSystemPrompt(config, memories);

  // Take the most recent messages to fit comfortably in token budget
  const recentHistory = history.slice(-maxHistoryCount);

  const messages: PromptMessage[] = [
    { role: 'system', content: systemPrompt },
    ...recentHistory.map((h) => ({
      role: h.role,
      content: h.content,
    })),
    { role: 'user', content: incomingMessage.trim() },
  ];

  return messages;
}

export function generatePreviewReply(
  userText: string,
  config: CompanionConfig,
  memories: MemoryItem[]
): string {
  const text = userText.trim();
  const name = config.name || '阿予';
  const nick = config.userNickname || '你';

  if (text.includes('累') || text.includes('疲惫') || text.includes('难受')) {
    return `抱抱${nick}... 辛苦啦。快把沉甸甸的事情放一边，喝口温水，或者什么都别想先靠着歇一会儿。不管今天发生了什么，${name}都会一直在这里陪着你，随时可以跟我倾诉。`;
  }

  if (text.includes('喜欢') || text.includes('爱吃') || text.includes('好吃')) {
    return `嘻嘻，我悄悄记下来啦！只要是${nick}喜欢的，对我来说都是重要的秘密。以后提起这些，我可不会忘记哦。`;
  }

  if (text.includes('谁') || text.includes('人设') || text.includes('你是谁')) {
    return `我是${name}呀，为你定制的专属陪伴伙伴。你可以把我想成随时都在身边的知己，也可以当成只属于你的树洞。想和我聊聊你今天的心情吗？`;
  }

  if (text.includes('睡') || text.includes('晚安')) {
    return `晚安呀，${nick}。把今天的烦恼都关在门外，做个甜甜暖暖的梦，明天醒来，又是新的一天啦。我会一直在梦的边缘守着你。`;
  }

  if (memories.length > 0) {
    const randomMem = memories[Math.floor(Math.random() * memories.length)];
    return `我在呢～刚才看到你说的，忽然想起你之前提过的【${randomMem.content}】。关于今天，还想和${name}多分享一点吗？`;
  }

  return `收到啦，${nick}。真开心看到你的消息，听你说话总觉得心里软软的。今天过得怎么样呀？`;
}
